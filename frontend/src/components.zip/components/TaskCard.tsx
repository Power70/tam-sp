import { useState } from 'react';
import DOMPurify from 'dompurify';
import { STATUS_LABELS, TASK_STATUSES, type Task, type TaskStatus } from '../api/taskApi';
import StatusBadge from './StatusBadge';

// Mirrors the styles applied in TipTap so saved formatting renders properly on screen
const RICH_TEXT_STYLES = `
  whitespace-pre-wrap break-words
  [&_ul]:my-2 [&_ul]:list-disc [&_ul]:pl-6 [&_ul_ul]:my-1
  [&_ol]:my-2 [&_ol]:list-decimal [&_ol]:pl-6 [&_ol_ol]:my-1
  [&_li]:pl-1
  [&_a]:text-teal-700 [&_a]:underline [&_a]:break-all
  [&_strong]:font-bold
  [&_em]:italic
  [&_h1]:text-2xl [&_h1]:font-bold [&_h1]:mt-5 [&_h1]:mb-3
  [&_h2]:text-xl [&_h2]:font-bold [&_h2]:mt-4 [&_h2]:mb-2
  [&_h3]:text-lg [&_h3]:font-bold [&_h3]:mt-3 [&_h3]:mb-2
  [&_h4]:text-base [&_h4]:font-bold [&_h4]:mt-3 [&_h4]:mb-2
  [&_p]:mb-2 [&_p:last-child]:mb-0
  [&_blockquote]:border-l-4 [&_blockquote]:border-gray-300 [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:my-3
  [&_hr]:my-4 [&_hr]:border-t [&_hr]:border-gray-200
`;

interface TaskCardProps {
  task: Task;
  updating: boolean;
  onStatusChange: (id: number, status: TaskStatus) => Promise<void>;
}

function formatCreatedAt(value?: string): string {
  if (!value) return 'Unknown date';
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(
    new Date(value)
  );
}

function sanitizeDescription(value: string): string {
  const clean = DOMPurify.sanitize(value);
  const container = document.createElement('div');
  container.innerHTML = clean;
  container.querySelectorAll('a').forEach((link) => {
    link.setAttribute('target', '_blank');
    link.setAttribute('rel', 'noopener noreferrer');
  });
  return container.innerHTML;
}

export default function TaskCard({ task, updating, onStatusChange }: TaskCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const description = task.description ? sanitizeDescription(task.description) : '';

  return (
    <>
      <article
        className="cursor-pointer rounded-xl border border-gray-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
        onClick={() => setIsModalOpen(true)}
      >
        <div className="flex items-start justify-between gap-4">
          <h3 className="m-0 text-[19px] font-semibold leading-7">{task.title}</h3>
          <StatusBadge status={task.status} />
        </div>
        
        {description ? (
          <div
            className={`task-description my-4 line-clamp-4 overflow-hidden text-[18px] leading-7 text-gray-600 ${RICH_TEXT_STYLES}`}
            dangerouslySetInnerHTML={{ __html: description }}
          />
        ) : (
          <p className="my-4 text-[18px] text-gray-500">No description provided.</p>
        )}

        <div
          className="flex items-center justify-between gap-3 border-t border-gray-200 pt-3"
          onClick={(event) => event.stopPropagation()}
        >
          <time className="text-[16px] text-gray-500" dateTime={task.created_at}>
            Created {formatCreatedAt(task.created_at)}
          </time>
          <select
            className="min-h-12 rounded-lg border border-gray-300 bg-white px-3 text-[17px] text-gray-700 disabled:cursor-wait disabled:opacity-60"
            aria-label={`Status for ${task.title}`}
            value={task.status}
            disabled={updating}
            onChange={(event) => void onStatusChange(task.id, event.target.value as TaskStatus)}
          >
            {TASK_STATUSES.map((status) => (
              <option key={status} value={status}>
                {STATUS_LABELS[status]}
              </option>
            ))}
          </select>
        </div>
      </article>

      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby={`modal-title-${task.id}`}
          onClick={() => setIsModalOpen(false)}
        >
          <section
            className="relative flex max-h-[90vh] w-full max-w-2xl flex-col rounded-2xl bg-white shadow-xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex shrink-0 items-center justify-between border-b border-gray-200 p-5 sm:p-6">
              <h2 id={`modal-title-${task.id}`} className="m-0 pr-4 text-xl font-bold">
                {task.title}
              </h2>
              <button
                className="flex size-8 shrink-0 items-center justify-center rounded-full bg-gray-100 text-xl text-gray-600 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
                type="button"
                onClick={() => setIsModalOpen(false)}
                aria-label="Close modal"
              >
                ×
              </button>
            </div>

            <div className="overflow-y-auto p-5 sm:p-6">
              <div className="mb-4">
                <StatusBadge status={task.status} />
              </div>
              {description ? (
                <div
                  className={`task-description text-[18px] leading-7 text-gray-700 ${RICH_TEXT_STYLES}`}
                  dangerouslySetInnerHTML={{ __html: description }}
                />
              ) : (
                <p className="text-[18px] text-gray-500">No description provided.</p>
              )}
            </div>

            <div className="flex shrink-0 items-center justify-between rounded-b-2xl border-t border-gray-200 bg-gray-50 p-5 sm:p-6">
              <time className="text-[16px] text-gray-500" dateTime={task.created_at}>
                Created {formatCreatedAt(task.created_at)}
              </time>
              <select
                className="min-h-12 rounded-lg border border-gray-300 bg-white px-3 text-[17px] text-gray-700 disabled:cursor-wait disabled:opacity-60"
                value={task.status}
                disabled={updating}
                onChange={(event) => void onStatusChange(task.id, event.target.value as TaskStatus)}
              >
                {TASK_STATUSES.map((status) => (
                  <option key={status} value={status}>
                    {STATUS_LABELS[status]}
                  </option>
                ))}
              </select>
            </div>
          </section>
        </div>
      )}
    </>
  );
}