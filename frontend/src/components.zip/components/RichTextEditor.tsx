import { useEffect } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import type { Editor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Placeholder from '@tiptap/extension-placeholder';
import type { ReactNode } from 'react';

import {
  Bold,
  Italic,
  List,
  ListOrdered,
  Link as LinkIcon,
  RemoveFormatting,
} from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

interface ToolbarButtonProps {
  label: string;
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: ReactNode;
}

function emptyToString(editor: Editor): string {
  return editor.isEmpty ? '' : editor.getHTML();
}

function ToolbarButton({
  label,
  active = false,
  disabled = false,
  onClick,
  children,
}: ToolbarButtonProps) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      aria-pressed={active}
      disabled={disabled}
      onMouseDown={(event) => event.preventDefault()}
      onClick={onClick}
      className={`
        flex h-10 min-w-0 w-full items-center justify-center
        rounded-md transition-colors duration-150
        sm:h-8 sm:w-8 sm:min-w-8 sm:shrink-0
        disabled:cursor-not-allowed disabled:opacity-40
        ${
          active
            ? 'bg-teal-100 text-teal-800'
            : 'text-gray-600 hover:bg-gray-200 hover:text-gray-900'
        }
      `}
    >
      {children}
    </button>
  );
}

function ToolbarDivider() {
  return (
    <div className="hidden h-5 w-px shrink-0 bg-gray-200 sm:block" />
  );
}

export default function RichTextEditor({
  value,
  onChange,
  disabled = false,
}: RichTextEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Link.configure({
        openOnClick: false,
        autolink: true,
        linkOnPaste: true,
      }),
      Placeholder.configure({
        placeholder: 'Add details (optional)',
      }),
    ],
    content: value || '',
    editable: !disabled,
    parseOptions: {
      // Prevents TipTap from squashing newlines and multiple spaces on paste
      preserveWhitespace: 'full', 
    },
    editorProps: {
      attributes: {
        'aria-label': 'Task description',
      },
    },
    onUpdate: ({ editor: currentEditor }) => {
      onChange(emptyToString(currentEditor));
    },
  });

  useEffect(() => {
    editor?.setEditable(!disabled);
  }, [editor, disabled]);

  useEffect(() => {
    if (!editor) return;
    const currentContent = emptyToString(editor);
    const nextContent = value || '';
    if (currentContent !== nextContent) {
      editor.commands.setContent(nextContent || '<p></p>');
    }
  }, [editor, value]);

  if (!editor) {
    return (
      <div className="w-full min-w-0 overflow-hidden rounded-lg border border-gray-300">
        <div className="h-12 animate-pulse bg-gray-50" />
        <div className="min-h-36 animate-pulse bg-white" />
      </div>
    );
  }

  const handleLink = () => {
    const previousUrl = editor.getAttributes('link').href;
    const url = window.prompt('Enter link URL', previousUrl || '');

    if (url === null) return;
    if (!url.trim()) {
      editor.chain().focus().extendMarkRange('link').unsetLink().run();
      return;
    }
    editor.chain().focus().extendMarkRange('link').setLink({ href: url.trim() }).run();
  };

  return (
    <div
      className={`
        w-full min-w-0 overflow-hidden rounded-lg border bg-white
        transition-all duration-150
        ${
          disabled
            ? 'border-gray-200 bg-gray-50'
            : 'border-gray-300 focus-within:border-teal-600 focus-within:ring-2 focus-within:ring-teal-100'
        }
      `}
    >
      {/* Responsive toolbar */}
      <div className="
        grid w-full grid-cols-4 gap-1
        border-b border-gray-200 bg-gray-50 p-2
        sm:flex sm:flex-wrap sm:items-center sm:gap-1
      ">
        <ToolbarButton label="Bold" active={editor.isActive('bold')} disabled={disabled} onClick={() => editor.chain().focus().toggleBold().run()}>
          <Bold size={17} strokeWidth={2.2} />
        </ToolbarButton>
        <ToolbarButton label="Italic" active={editor.isActive('italic')} disabled={disabled} onClick={() => editor.chain().focus().toggleItalic().run()}>
          <Italic size={17} />
        </ToolbarButton>
        <ToolbarDivider />
        <ToolbarButton label="Bulleted list" active={editor.isActive('bulletList')} disabled={disabled} onClick={() => editor.chain().focus().toggleBulletList().run()}>
          <List size={18} />
        </ToolbarButton>
        <ToolbarButton label="Numbered list" active={editor.isActive('orderedList')} disabled={disabled} onClick={() => editor.chain().focus().toggleOrderedList().run()}>
          <ListOrdered size={18} />
        </ToolbarButton>
        <ToolbarDivider />
        <ToolbarButton label="Insert link" active={editor.isActive('link')} disabled={disabled} onClick={handleLink}>
          <LinkIcon size={17} />
        </ToolbarButton>
        <ToolbarButton label="Clear formatting" disabled={disabled} onClick={() => editor.chain().focus().clearNodes().unsetAllMarks().run()}>
          <RemoveFormatting size={17} />
        </ToolbarButton>
      </div>

      <EditorContent
        editor={editor}
        className="
          w-full min-w-0 text-sm text-gray-700
          [&_.tiptap]:box-border
          [&_.tiptap]:min-h-36
          [&_.tiptap]:max-h-80 
          [&_.tiptap]:overflow-y-auto
          [&_.tiptap]:w-full
          [&_.tiptap]:max-w-full
          [&_.tiptap]:overflow-x-hidden
          [&_.tiptap]:break-words
          [&_.tiptap]:p-3
          [&_.tiptap]:leading-relaxed
          [&_.tiptap]:outline-none
          [&_.tiptap]:whitespace-pre-wrap

          /* Headings */
          [&_.tiptap_h1]:text-2xl [&_.tiptap_h1]:font-bold [&_.tiptap_h1]:mt-5 [&_.tiptap_h1]:mb-3
          [&_.tiptap_h2]:text-xl [&_.tiptap_h2]:font-bold [&_.tiptap_h2]:mt-4 [&_.tiptap_h2]:mb-2
          [&_.tiptap_h3]:text-lg [&_.tiptap_h3]:font-bold [&_.tiptap_h3]:mt-3 [&_.tiptap_h3]:mb-2
          [&_.tiptap_h4]:text-base [&_.tiptap_h4]:font-bold [&_.tiptap_h4]:mt-3 [&_.tiptap_h4]:mb-2

          /* Text & Paragraphs */
          [&_.tiptap_p]:mb-2
          [&_.tiptap_p:last-child]:mb-0
          
          /* Lists */
          [&_.tiptap_ul]:my-2 [&_.tiptap_ul]:list-disc [&_.tiptap_ul]:pl-6 [&_.tiptap_ul_ul]:my-1
          [&_.tiptap_ol]:my-2 [&_.tiptap_ol]:list-decimal [&_.tiptap_ol]:pl-6 [&_.tiptap_ol_ol]:my-1
          [&_.tiptap_li]:pl-1

          /* Blocks */
          [&_.tiptap_blockquote]:border-l-4 [&_.tiptap_blockquote]:border-gray-300 [&_.tiptap_blockquote]:pl-4 [&_.tiptap_blockquote]:italic [&_.tiptap_blockquote]:my-3
          [&_.tiptap_hr]:my-4 [&_.tiptap_hr]:border-t [&_.tiptap_hr]:border-gray-200

          /* Inline formatting */
          [&_.tiptap_a]:break-all [&_.tiptap_a]:text-teal-700 [&_.tiptap_a]:underline
          [&_.tiptap_strong]:font-bold [&_.tiptap_em]:italic

          /* Placeholder logic */
          [&_.tiptap_p.is-editor-empty:first-child::before]:pointer-events-none
          [&_.tiptap_p.is-editor-empty:first-child::before]:float-left
          [&_.tiptap_p.is-editor-empty:first-child::before]:h-0
          [&_.tiptap_p.is-editor-empty:first-child::before]:text-gray-400
          [&_.tiptap_p.is-editor-empty:first-child::before]:content-[attr(data-placeholder)]
        "
      />
    </div>
  );
}