interface ErrorBannerProps {
  message: string;
  onRetry: () => void;
}

export default function ErrorBanner({ message, onRetry }: ErrorBannerProps) {
  return (
    <div
      className="mb-5 flex items-center justify-between gap-4 rounded-lg border border-red-300 bg-red-100 px-4 py-4 text-[17px] leading-6 text-red-800"
      role="alert"
    >
      <span>{message}</span>
      <button
        className="min-h-11 rounded-lg border border-red-800 bg-white px-4 text-[17px] font-semibold"
        type="button"
        onClick={onRetry}
      >
        Retry
      </button>
    </div>
  );
}
